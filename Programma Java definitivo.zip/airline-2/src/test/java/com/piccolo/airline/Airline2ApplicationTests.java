package com.piccolo.airline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Airline2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
